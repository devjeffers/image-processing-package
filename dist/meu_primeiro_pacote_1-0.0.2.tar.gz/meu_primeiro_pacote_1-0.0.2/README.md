# meu_primeiro_pacote

Description. 
The package meu_primeiro_pacote is used to:
	- Histogram matching
	- Structural similarity
	- Resize image
Utils:
	- Read image
	- Save image
	- Plot image
	- Plot result
	- Plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install meu_primeiro_pacote

```bash
pip install meu_primeiro_pacote

```

## Author
Jefferson

## License
[MIT](https://choosealicense.com/licenses/mit/)